#pragma once


/* types */

typedef unsigned long ulong_t;

/* includes */

// stl
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>