#pragma once

#include "includes.h"
#include "scan.h"

// remove some unwanted characters from the input string
extern PS_NOINLINE char* util_trim_pattern_str(const char* str);